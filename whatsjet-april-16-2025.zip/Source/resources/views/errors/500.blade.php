@extends('errors::minimal')

@section('title', __tr('Server Error'))
@section('code', '500')
@section('message', __tr('Server Error'))
