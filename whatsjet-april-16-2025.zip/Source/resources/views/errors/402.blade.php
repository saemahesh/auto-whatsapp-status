@extends('errors::minimal')

@section('title', __tr('Payment Required'))
@section('code', '402')
@section('message', __tr('Payment Required'))
