@extends('errors::minimal')

@section('title', __tr('Service Unavailable'))
@section('code', '503')
@section('message', __tr('Service Unavailable'))
