<?php

/**
 * PageEngineInterface.php - Interface file
 *
 * This file is part of the Page component.
 *-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Page\Interfaces;

interface PageEngineInterface
{
}
