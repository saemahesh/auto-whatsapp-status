<?php
/**
* BotFlowEngineInterface.php - Interface file
*
* This file is part of the BotFlow component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\BotReply\Interfaces;

interface BotFlowEngineInterface
{
}