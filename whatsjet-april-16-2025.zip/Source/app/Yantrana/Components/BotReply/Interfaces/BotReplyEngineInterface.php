<?php
/**
* BotReplyEngineInterface.php - Interface file
*
* This file is part of the BotReply component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\BotReply\Interfaces;

interface BotReplyEngineInterface
{
}