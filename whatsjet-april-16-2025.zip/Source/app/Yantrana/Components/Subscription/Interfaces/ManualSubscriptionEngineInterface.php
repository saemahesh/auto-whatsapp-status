<?php
/**
* ManualSubscriptionEngineInterface.php - Interface file
*
* This file is part of the ManualSubscription component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Subscription\Interfaces;

interface ManualSubscriptionEngineInterface
{
}
