<?php

/**
 * SubscriptionRepositoryInterface.php - Interface file
 *
 * This file is part of the Subscription component.
 *-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Subscription\Interfaces;

interface SubscriptionRepositoryInterface
{
}
