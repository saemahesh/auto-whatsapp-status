<?php

namespace App\Yantrana\Base;

use App\Yantrana\__Laraware\Core\CoreRepository;

abstract class BaseRepository extends CoreRepository
{
}
