<?php
/**
 *  YesFileStorage Configurations
 *
 *  This configuration file is part of YesFileStorage
 *
 *------------------------------------------------------------------------------------------------*/
return [
    /* authority configurations
     *--------------------------------------------------------------------------------------------*/
    'storage_paths' => [],
];
